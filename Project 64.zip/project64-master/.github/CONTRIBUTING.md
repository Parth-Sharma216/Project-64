# Introduction

First of all, thank you for considering contributing to Project64! Project64 is an open-source project and contributions by the community help fix bugs, add new features, and improve the project.

Following these guidelines will help make sure that users and developers alike can work together to achieve the projects goals.

Project64 is an open-source project and we love to receive contributions from the community. There are many ways to contribute, from writing and improving the documentation, testing, submitting bug reports and feature requests, or writing code which can be incorporated into Project64 itself.

Please don't use the issue tracker for support questions. Please join the Discord so the community can help with your issue!
